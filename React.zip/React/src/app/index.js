// JavaScript source code
import React from 'react';
import { render } from 'react-dom';
import Menu from '../components/menu';
import '../style.css';



const reactElement = React.createElement(
    'h3', { className: 'header' }, "REACT"
);


class App extends React.Component {
    constructor(props) {
        console.log("Constructor")
        super(props);
        this.state = {
            menu: [{ value: "Home", link: "/" },
            { value: "About Us", link: "/about" },
            { value: "Service", link: "/service" },
            { value: "Contact Us", link: "/contact" }
            ]
        }
        
    }
    changeMenu(_index,e) {
       // console.log(e, this);
        e.preventDefault();
        let _menu = [...this.state.menu];
        _menu[_index].value = e.target.value;
        this.setState({
            menu: _menu
        });
    }
    componentWillMount() {
        console.log("Component will mount");
    }

    componentDidMount() {
        console.log("component did mount");
    }

    componentWillUpdate() {
        console.log("Component will update");
    }

    componentDidUpdate() {
        console.log("component did update");
    }

    componentWillUnmount() {
        console.log("Component will unmount");
    }

   
   
   
    render() {
        console.log("render");
        return (
           
            <div>
                <Menu menuList={this.state.menu} />
                {reactElement}
                <h1>Hello World</h1>
                {this.state.menu.map((x, i) => {
                    return <input type="text" value={x.value} key={i} onChange={(e) => this.changeMenu(i,e)}/>
                })}
               
            </div>
            ); 
        
    }
}

render(<App/>, document.getElementById("app"));
