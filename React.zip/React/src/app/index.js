// JavaScript source code
import React from 'react';
import { render } from 'react-dom';
import Menu from '../components/menu';
import Contact from '../components/contact/contact';
import '../style.css';

const inlinestyle = {
    padding: '10px',
    textIndent:'5px'
}

const reactElement = React.createElement(
    'h3', { className: 'header' }, "REACT"
);


class App extends React.Component {
    constructor(props) {
        console.log("Constructor")
        super(props);
        this.textInput = React.createRef();
        this.textBox = null;
        this.state = {
            menu: [{ value: "Home", link: "/" },
            { value: "About Us", link: "/about" },
            { value: "Service", link: "/service" },
            { value: "Contact Us", link: "/contact" }
            ],
            keyCount:0,
        }

        this.setColor = ele => {
            this.textBox = ele;
          //  this.changeColor();
        }
        
    }
    changeMenu(_index,e) {
       // console.log(e, this);
        e.preventDefault();
        let _menu = JSON.parse(JSON.stringify(this.state.menu));
        _menu[_index].value = e.target.value;
        this.setState({
            menu: _menu
        });
    }
    changeColor(_this) {
        this.textBox.value.length > 10 ?
            this.textBox.style = "color:red" : this.textBox.style = "color:green";
    }

    componentWillMount() {
        console.log("Component will mount");
    }

    componentDidMount() {
        console.log("component did mount");
        this.textInput.current.focus();
    }

    componentWillUpdate(prevProps, prevState) {
        console.log("Component will update", prevProps, prevState);
    }

    componentDidUpdate(prevProps, prevState,nextState) {
        console.log("component did update", prevProps, prevState, nextState);
    }

    componentWillUnmount() {
        console.log("Component will unmount");
    }

    componentWillReceiveProps(nextProps) {
        console.log("Parent-componentWillReceiveProps", nextProps, this.props);
    }
   
   
    render() {
        console.log("render");
        return (
           
            <>
                <Menu menuList={this.state.menu} />
                {reactElement}
                <h1>Hello World</h1>
                {this.state.menu.map((x, i) => {
                    return <input style={inlinestyle} type="text" tabIndex={i+1} value={x.value} key={i} onChange={(e) => this.changeMenu(i, e)} />
                })}
                <input type="text" ref={this.textInput} placeholder="Test" />
                <input type="text" ref={this.setColor} placeholder="Test Box" onChange={() => this.changeColor()} />
                <br />
                <Contact/>
            </>
            ); 
        
    }
}

render(<App/>, document.getElementById("app"));
