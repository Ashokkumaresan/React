// JavaScript source code
import React from 'react';
import { render } from 'react-dom';
import democss from '../../demo.module.css';

class Menu extends React.Component {
    componentWillUnmount() {
        console.log("Component will unmount");
    }
    componentWillReceiveProps(nextProps) {
        console.log("componentWillReceiveProps", nextProps,this.props);
    }
    shouldComponentUpdate(nextProps, nextState) {
        console.log("Should Update", nextProps, nextState, this.props);

        return true;
    }
    
    render() {
        return (
            <ul className={democss.anchor}>{this.props.menuList.map((x, i) => {
                return <li key={i}><a href={x.link}>{x.value}</a> </li> })}
                
            </ul>
            );
    }
}

export default Menu;
