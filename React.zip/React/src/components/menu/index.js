// JavaScript source code
import React from 'react';
import { render } from 'react-dom';

class Menu extends React.Component {
    componentWillUnmount() {
        console.log("Component will unmount");
    }
    componentWillReceiveProps(nextProps) {
        console.log("Update", nextProps,this.props);
    }
    
    render() {
        return (
            <ul>{this.props.menuList.map((x, i) => {
                return <li key={i}><a href={x.link}>{x.value}</a> </li> })}
                
            </ul>
            );
    }
}

export default Menu;
