// JavaScript source code
import React from 'react';
import democss from '../../demo.module.css';
import * as action_type from '../../Store/actions';
import { connect } from 'react-redux';

class Menu extends React.Component {
    componentWillUnmount() {
        console.log("Component will unmount");

    }
    componentWillReceiveProps(nextProps) {
        console.log("componentWillReceiveProps", nextProps,this.props);
    }
    shouldComponentUpdate(nextProps, nextState) {
        console.log("Should Update", nextProps, nextState, this.props);

        return true;
    }
    
    render() {
        return (
            <>
                <h5>{this.props.user.length}</h5>
                <input type="button" value="Load" onClick={()=>this.props.LOAD_USER()} />
            <ul className={democss.anchor}>{this.props.ctr.map((x, i) => {
                return <li key={i}><a href={x.link}>{x.value}</a> </li> })}
                
                </ul>
                </>
            );
    }
}

const mapProperties = state => {
    return {
        ctr: state.menu,
        user: state.UserList
    };
}

const dispatch_action = dispatch => {
    return {
        LOAD_USER: () => dispatch(action_type._load_user()),
        ADD_USER: () => dispatch(action_type._add_user())
    }
}

export default connect(mapProperties, dispatch_action)(Menu);
