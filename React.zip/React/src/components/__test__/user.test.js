test('Test addition', () => {
    expect(100 + 200).toBe(300)
});