// JavaScript source code
import React from 'react';
import { render } from 'react-dom';

class Contact extends React.Component {
    constructor(props) {
        super(props);        
    }
    render() {
        return (
            <h5>Key Press Count:{this.props.count > 10 ? new Error("Invalid Stroke") : this.props.count}</h5>
            );
    }
}

export default Contact;
