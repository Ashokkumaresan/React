// JavaScript source code
import React from 'react';
import { render } from 'react-dom';

class Contact extends React.Component {
    render() {
        return (
            <h5>Key Press Count:</h5>
            );
    }
}

export default Contact;
