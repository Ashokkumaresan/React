// JavaScript source code
export const LOAD_USER = "LOAD_USER";
export const ADD_USER = "ADD_USER";

let _alluser_list = (_res) => {
    return {
        type: LOAD_USER,
        user_list: _res
    }
}
export const _load_user = () => {
    return dispatch => {
        makeAjaxCall("https://jsonplaceholder.typicode.com/users", "GET").then((res) => {
            console.log("Response", res);
            dispatch(_alluser_list(res));
            //UserStore = createStore({ userReducer, res });
        }).catch((err) => {
            console.log("Error", err);
            dispatch(_alluser_list([]));
        })
    }

    let _obj = {
        type: LOAD_USER,
        user_list:[]
    }
 

   /* return {
        type: LOAD_USER,
        user_list: makeAjaxCall("https://jsonplaceholder.typicode.com/users", "GET").then((res) => {
            console.log("Response", res);
            _obj.user_list = res;
            return _obj;
            //UserStore = createStore({ userReducer, res });
        }).catch((err) => {
            console.log("Error", err);
            return _obj;
        })
    };*/
}

export const _add_user = () => {
    return {
        type: ADD_USER,
        user_data: {}
    };
}
function makeAjaxCall(url, methodType) {
    var promiseObj = new Promise(function (resolve, reject) {
        var xhr = new XMLHttpRequest();
        xhr.open(methodType, url, true);
        xhr.send();
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4) {
                if (xhr.status === 200) {
                    console.log("Success Call");
                    var resp = xhr.responseText;
                    var respJson = JSON.parse(resp);
                    resolve(respJson);
                } else {
                    reject(xhr.status);
                    console.log("Failed Call");
                }
            } else {
                console.log("Request going on");
            }
        }
        console.log("request sent succesfully");
    });
    return promiseObj;
}