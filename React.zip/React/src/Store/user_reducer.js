// JavaScript source code
import { userData } from './user_store';
import * as action_type from './actions';
let initial = {
    menu: [{ value: "Home", link: "/" },
    { value: "About Us", link: "/about" },
    { value: "Service", link: "/service" },
    { value: "Contact", link: "/contact" }
    ],
    keyCount: 0,
    UserList: []
}
const userReducer = (state = initial, action) => {
    switch (action.type) {
        case action_type.LOAD_USER:
            // state = [...state.UserList];
            //let _user = state.UserList;
            var newState = Object.assign({}, state);
          // let _arr = newState.UserList.filter(x => true);
            //_arr.push({ value: "Home", link: "/" });
            newState.UserList = action.user_list;
            state = newState;
            break;
        default:
            state = state;
            break;
    } 
    return state;
}

export default userReducer;