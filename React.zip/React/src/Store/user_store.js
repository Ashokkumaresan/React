// JavaScript source code
import { createStore, applyMiddleware } from 'redux';
import thunk from 'redux-thunk';
import userReducer from './user_reducer';

let userData = [];
//let UserStore;
//const UserStore = createStore({ userReducer, userData });
const logger = store => {
    return next => {
        return action => {
            console.log("Dispatching action", action);
                       let res = next(action);
            console.log("result of action", res);
            console.log("Log State", store.getState())
            return res
        }
    }
}
const UserStore = createStore(userReducer, applyMiddleware(logger, thunk));
function makeAjaxCall(url, methodType) {
    var promiseObj = new Promise(function (resolve, reject) {
        var xhr = new XMLHttpRequest();
        xhr.open(methodType, url, true);
        xhr.send();
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4) {
                if (xhr.status === 200) {
                    console.log("Success Call");
                    var resp = xhr.responseText;
                    var respJson = JSON.parse(resp);
                    resolve(respJson);
                } else {
                    reject(xhr.status);
                    console.log("Failed Call");
                }
            } else {
                console.log("Request going on");
            }
        }
        console.log("request sent succesfully");
    });
    return promiseObj;
}

makeAjaxCall("https://jsonplaceholder.typicode.com/users", "GET").then((res) => {
    console.log("Response", res);
    userData = res;
    //UserStore = createStore({ userReducer, res });
}).catch((err) => {
    console.log("Error", err);
    });

UserStore.subscribe(() => {
    console.log("Get state", UserStore.getState());
})
//const UserStore = createStore({});
export { UserStore, userData }

