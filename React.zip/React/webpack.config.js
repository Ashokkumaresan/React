// JavaScript source code
var path = require('path');
var HtmlWebpackPlugin = require('html-webpack-plugin');

var SOURCE = path.resolve(__dirname, "src");
var DEST = path.resolve(__dirname, "dist");

let config = {
    entry: SOURCE + "/app/index.js",
    output: {
        path: DEST + "/app",
        filename:'bundle.js'
    },
    module: {
        rules: [
            {
                test: /\.jsx|js?/,
                exclude:'/node_modules',
                use:'babel-loader',
            },
            {
                test: /\.less?/,
                use:'less-loader'
            },
            {
                test: /\.css$/,
                use: 'style-loader'
            },
            {
                test: /\.css$/,
                loader: 'css-loader',
                options: {
                    modules: {                      
                        localIdentName: '[name]__[local]___[hash:base64:5]',                       
                        
                    },
                },
            },
      
        ]
    },
    plugins: [
      
        new HtmlWebpackPlugin({  // Also generate a test.html
            filename: './index.html',
            template: './src/index.html'
        })
    ]
}

module.exports = config;
